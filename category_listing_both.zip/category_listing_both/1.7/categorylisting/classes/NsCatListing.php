<?php

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;
use PrestaShop\PrestaShop\Adapter\Category\CategoryProductSearchProvider;
use PrestaShop\PrestaShop\Adapter\Image\ImageRetriever;
use PrestaShop\PrestaShop\Adapter\Product\PriceFormatter;
use PrestaShop\PrestaShop\Core\Product\ProductListingPresenter;
use PrestaShop\PrestaShop\Adapter\Product\ProductColorsRetriever;
use PrestaShop\PrestaShop\Core\Product\Search\ProductSearchContext;
use PrestaShop\PrestaShop\Core\Product\Search\ProductSearchQuery;
use PrestaShop\PrestaShop\Core\Product\Search\SortOrder;


class NsCatListing extends ObjectModel
{			
   /* NdiagaSoft*/    
 public static function nkaCategory($id_category,$id_lang){	 
  
  $nka_category=new Category($id_category,$id_lang);		  	
  return  $nka_category;
  
 }
	    


		
  public static function getProducts($idCategory){  
  
    $category = new Category((int)$idCategory);
  
  $id_lang=Context::getContext()->language->id;
  $products=$category->getProducts($id_lang,1,100,'id_product','DESC',false);	
 // return $products;		 
  
  
  
         
        $showPrice = (bool) Configuration::get('CATEGORYPRODUCTS_DISPLAY_PRICE');

        $searchProvider = new CategoryProductSearchProvider(
            Context::getContext()->getTranslator(),
            $category
        );

        $context = new ProductSearchContext(Context::getContext());

        $query = new ProductSearchQuery();

        $nProducts = (int) Configuration::get('CATEGORYPRODUCTS_DISPLAY_PRODUCTS') + 1; // +1 If current product is found

        $query
            ->setResultsPerPage($nProducts)
            ->setPage(1)
        ;

        $query->setSortOrder(SortOrder::random());

        $result = $searchProvider->runQuery(
            $context,
            $query
        );

        $assembler = new ProductAssembler(Context::getContext());
        $presenterFactory = new ProductPresenterFactory(Context::getContext());
        $presentationSettings = $presenterFactory->getPresentationSettings();
        $presenter = new ProductListingPresenter(
            new ImageRetriever(
                Context::getContext()->link
            ),
            Context::getContext()->link,
            new PriceFormatter(),
            new ProductColorsRetriever(),
            Context::getContext()->getTranslator()
        );

        $productsForTemplate = array();

        $presentationSettings->showPrices = $showPrice;

        //$products = $result->getProducts();

        foreach ($products as $rawProduct) {
            // Not duplicate current product
            if (count($productsForTemplate) < (int) Configuration::get('CATEGORYPRODUCTS_DISPLAY_PRODUCTS')) {
                $productsForTemplate[] = $presenter->present(
                    $presentationSettings,
                    $assembler->assembleProduct($rawProduct),
                    Context::getContext()->language
                );
            }
        }

        return  $products;    //$productsForTemplate;
  

  }
	
}


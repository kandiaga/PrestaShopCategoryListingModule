<?php
/*
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2019 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_'))
	exit;
use PrestaShop\PrestaShop\Core\Module\WidgetInterface;
require_once(dirname(__FILE__) . '/classes/NsCatListing.php');  

	
class categorylisting extends Module implements WidgetInterface
{  
   private $templateFile;
   private $template_path;
	public function __construct()
	{
		$this->name = 'categorylisting';
		$this->tab = 'front_office_features';
		$this->version = '1.0.0';
		$this->author = 'NdiagaSoft';

		$this->bootstrap = true;
		parent::__construct();	

		$this->displayName = $this->l('Category Listing');
		$this->description = $this->l('Category listing in product list page.');
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);			
		$this->templateFile = 'module:categorylisting/views/templates/hook/categorylisting.tpl';
		
		$this->template_path = 'module:categorylisting/views/templates/my_list.tpl';
		
	}

	public function install()
	{
		
		if (!parent::install() ||	
            !$this->registerHook('displayHome')|| 		
			!$this->registerHook('categoryListing')||
			!Configuration::updateValue('CategoryListing_Cat',1)||
			!Configuration::updateValue('show_category_image',0)||
			!Configuration::updateValue('show_category_description',1)||
			!Configuration::updateValue('CategoryListing_Nbre',6)
			)
			return false;
			
		return true;
	}

	public function uninstall()
	{
		if (!parent::uninstall())
			return false;
		return true;
	}

	public function getContent()
	{
		$output = '';
		$nbr = Tools::getValue('CategoryListing_Nbre');
		$cat =Tools::getValue('CategoryListing_Cat');
		$cat_image=Tools::getValue('show_category_image');
		$cat_description=Tools::getValue('show_category_description');
		
		if (Tools::isSubmit('submitCategoryListing')) {
            if (!($cat = Tools::getValue('CategoryListing_Cat')) || empty($cat)) {
                $output .= $this->displayError($this->l('You must fill in the \'Products displayed\' field.'));
            } elseif ((int) ($cat) == 0) {
                $output .= $this->displayError($this->l('Invalid number.'));
            } else {                
				 Configuration::updateValue('CategoryListing_Nbre', (int)$nbr);
                Configuration::updateValue('CategoryListing_Cat', (int)$cat);
				Configuration::updateValue('show_category_image', (int)$cat_image);
				Configuration::updateValue('show_category_description', (int)$cat_description);
                $output .= $this->displayConfirmation($this->l('Settings updated.'));
            }
        }
        $output.=$this->renderForm();
		
		
		$output.='<br/>'. $this->displayAdvertising();
		
		return $output;
	}

    public function renderWidget($hookName, array $params)   
	{               
	$this->smarty->assign($this->getWidgetVariables($hookName, $params));   
	return $this->fetch($this->templateFile);  
	}
	public function getWidgetVariables($hookName, array $params)   
	{    
      
      $id_lang=(int)$this->context->language->id;
	  
	return array(
	 'id_lang'=>$id_lang, 
	 
	);   
	
	
	}

	public function hookCategoryListing($params)
	{	   
	
	$id_category=(int)Configuration::get('CategoryListing_Cat');
      $id_lang=(int)$this->context->language->id;
	  $currency = $this->context->currency;
	  
	  $product_categories=Category::getNestedCategories($id_category,$id_lang,true);
	  
		    foreach ($product_categories as &$row)
		{
			$row['id_image'] = Tools::file_exists_cache(_PS_CAT_IMG_DIR_.$row['id_category'].'.jpg') ? 
			(int)$row['id_category'] : Language::getIsoById($id_lang).'-default';
			$row['legend'] = 'no picture';
		}  
	  
	$this->context->smarty->assign( 
	array(
       'id_lang'=>(int)$this->context->language->id,
      'categories'=>$product_categories,      	
	  'template_path'=>$this->template_path,
	  'currency'=>$currency,
	  'show_category_image'=>(int) Configuration::get('show_category_image'),
	  'show_category_description'=>(int)Configuration::get('show_category_description'),
	  'show_product_number'=>(int)Configuration::get('CategoryListing_Nbre'),
	  'root_category_default'=>$id_category,
      
		)            
		);  
		
		return $this->fetch($this->templateFile);
		/*return $this->display(__FILE__, 'categorylisting.tpl');*/
	}
	
	public function hookHeader()
	{
		$this->context->controller->addJS(($this->_path).'views/js/categorylisting.js');
		$this->context->controller->addCSS(($this->_path).'views/css/categorylisting.css', 'all');
	}

	public function hookdisplayHome($params)
	{
	  
        return $this->hookCategoryListing($params);      	  
		
	}
	
	
	    public function renderForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs'
                ),
                'input' => array(
				array(
                        'type' => 'text',
                        'label' => $this->trans('Number of products to be displayed', array(), 'Modules.Featuredproducts.Admin'),
                        'name' => 'CategoryListing_Nbre',
                        'class' => 'fixed-width-xs',
                        'desc' => $this->trans('Set the number of products that you would like to display for each category (default: 6).', array(), 'Modules.Featuredproducts.Admin'),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->trans('Category from which to pick subcategories and products to be displayed', array(), 'Modules.Featuredproducts.Admin'),
                        'name' => 'CategoryListing_Cat',
                        'class' => 'fixed-width-xs',
                        'desc' => $this->trans('Choose the root category ID of the products that you would like to display on homepage (default: 3 for "Root").', array(), 'Modules.Featuredproducts.Admin'),
                    ),			
                   
					array(
				'type' => 'switch',
						'label' => $this->l('Show category Image?'),
						'name' => 'show_category_image',
						'desc' => $this->l('you can choose to show the category image or not.'),
						'is_bool' => true,
						'values' => array(
							array(
								'id' => 'active_on',
								'value' => 1,
								'label' => $this->l('Light')
							),
							array(
								'id' => 'active_off',
								'value' => 0,
								'label' => $this->l('Dark')
							)
						),
					),
					
					array(
				'type' => 'switch',
						'label' => $this->l('Show Category Description?'),
						'name' => 'show_category_description',
						'desc' => $this->l('you can choose to show the category description or not.'),
						'is_bool' => true,
						'values' => array(
							array(
								'id' => 'active_on',
								'value' => 1,
								'label' => $this->l('Light')
							),
							array(
								'id' => 'active_off',
								'value' => 0,
								'label' => $this->l('Dark')
							)
						),
					),
					
					
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                )
            ),
        );
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int) Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ?
		Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitCategoryListing';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' 
		. $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );
        return $helper->generateForm(array($fields_form));
    }
    public function getConfigFieldsValues()
    {
        return array(
            
			 'CategoryListing_Nbre' => Tools::getValue('CategoryListing_Nbre', (int) Configuration::get('CategoryListing_Nbre')),
			 'CategoryListing_Cat' => Tools::getValue('CategoryListing_Cat', (int) Configuration::get('CategoryListing_Cat')),
			 'show_category_image' => Tools::getValue('show_category_image', (int) Configuration::get('show_category_image')),
			 'show_category_description' => Tools::getValue('show_category_description', (int)Configuration::get('show_category_description')),
        );
    }
   
	
	
	
	public function displayAdvertising()
    {
        $html = '
        <br/>
        <fieldset>
            <legend><img src="' . $this->_path . 'views/img/more.png" alt="" title="" /> ' . $this->l('More Modules & Themes ') . '</legend>
            <iframe src="http://prestatuts.com/advertising/prestashop_advertising.html" width="100%" height="420px;" border="0" style="border:none;"></iframe>
            </fieldset>';
        return $html;
    }
	
	

}
